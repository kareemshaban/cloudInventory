<?php

namespace App\Http\Controllers;

use App\Models\ContractNotcoveredCategoryClass;
use Illuminate\Http\Request;

class ContractNotcoveredCategoryClassController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(ContractNotcoveredCategoryClass $contractNotcoveredCategoryClass)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ContractNotcoveredCategoryClass $contractNotcoveredCategoryClass)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, ContractNotcoveredCategoryClass $contractNotcoveredCategoryClass)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ContractNotcoveredCategoryClass $contractNotcoveredCategoryClass)
    {
        //
    }
}
