<?php

namespace App\Http\Controllers;

use App\Models\balancebarcode;
use Illuminate\Http\Request;

class BalancebarcodeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(balancebarcode $balancebarcode)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(balancebarcode $balancebarcode)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, balancebarcode $balancebarcode)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(balancebarcode $balancebarcode)
    {
        //
    }
}
