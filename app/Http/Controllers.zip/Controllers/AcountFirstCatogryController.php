<?php

namespace App\Http\Controllers;

use App\Models\AcountFirstCatogry;
use Illuminate\Http\Request;

class AcountFirstCatogryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(AcountFirstCatogry $acountFirstCatogry)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(AcountFirstCatogry $acountFirstCatogry)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, AcountFirstCatogry $acountFirstCatogry)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(AcountFirstCatogry $acountFirstCatogry)
    {
        //
    }
}
