<?php

namespace App\Http\Controllers;

use App\Models\EmpCostFirst;
use Illuminate\Http\Request;

class EmpCostFirstController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(EmpCostFirst $empCostFirst)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(EmpCostFirst $empCostFirst)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, EmpCostFirst $empCostFirst)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(EmpCostFirst $empCostFirst)
    {
        //
    }
}
