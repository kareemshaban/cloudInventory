<?php

namespace App\Http\Controllers;

use App\Models\CarImages;
use Illuminate\Http\Request;

class CarImagesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(CarImages $carImages)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CarImages $carImages)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, CarImages $carImages)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CarImages $carImages)
    {
        //
    }
}
