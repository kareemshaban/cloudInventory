<?php

namespace App\Http\Controllers;

use App\Models\SalaryTaxGuid;
use Illuminate\Http\Request;

class SalaryTaxGuidController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(SalaryTaxGuid $salaryTaxGuid)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SalaryTaxGuid $salaryTaxGuid)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, SalaryTaxGuid $salaryTaxGuid)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SalaryTaxGuid $salaryTaxGuid)
    {
        //
    }
}
