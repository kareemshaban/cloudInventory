<?php

namespace App\Http\Controllers;

use App\Models\Optics;
use Illuminate\Http\Request;

class OpticsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Optics $optics)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Optics $optics)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Optics $optics)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Optics $optics)
    {
        //
    }
}
