<?php

namespace App\Http\Controllers;

use App\Models\SalaryTermsFieldApplay;
use Illuminate\Http\Request;

class SalaryTermsFieldApplayController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(SalaryTermsFieldApplay $salaryTermsFieldApplay)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SalaryTermsFieldApplay $salaryTermsFieldApplay)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, SalaryTermsFieldApplay $salaryTermsFieldApplay)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SalaryTermsFieldApplay $salaryTermsFieldApplay)
    {
        //
    }
}
