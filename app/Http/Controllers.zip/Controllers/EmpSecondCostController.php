<?php

namespace App\Http\Controllers;

use App\Models\EmpSecondCost;
use Illuminate\Http\Request;

class EmpSecondCostController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(EmpSecondCost $empSecondCost)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(EmpSecondCost $empSecondCost)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, EmpSecondCost $empSecondCost)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(EmpSecondCost $empSecondCost)
    {
        //
    }
}
