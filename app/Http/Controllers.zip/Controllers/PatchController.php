<?php

namespace App\Http\Controllers;

use App\Models\Patch;
use Illuminate\Http\Request;

class PatchController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Patch $patch)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Patch $patch)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Patch $patch)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Patch $patch)
    {
        //
    }
}
