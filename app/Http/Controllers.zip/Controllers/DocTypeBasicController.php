<?php

namespace App\Http\Controllers;

use App\Models\DocTypeBasic;
use Illuminate\Http\Request;

class DocTypeBasicController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(DocTypeBasic $docTypeBasic)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(DocTypeBasic $docTypeBasic)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, DocTypeBasic $docTypeBasic)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(DocTypeBasic $docTypeBasic)
    {
        //
    }
}
