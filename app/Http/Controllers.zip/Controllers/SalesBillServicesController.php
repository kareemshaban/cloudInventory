<?php

namespace App\Http\Controllers;

use App\Models\SalesBillServices;
use Illuminate\Http\Request;

class SalesBillServicesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(SalesBillServices $salesBillServices)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(SalesBillServices $salesBillServices)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, SalesBillServices $salesBillServices)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(SalesBillServices $salesBillServices)
    {
        //
    }
}
