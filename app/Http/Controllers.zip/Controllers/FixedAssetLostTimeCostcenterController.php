<?php

namespace App\Http\Controllers;

use App\Models\FixedAssetLostTimeCostcenter;
use Illuminate\Http\Request;

class FixedAssetLostTimeCostcenterController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(FixedAssetLostTimeCostcenter $fixedAssetLostTimeCostcenter)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(FixedAssetLostTimeCostcenter $fixedAssetLostTimeCostcenter)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, FixedAssetLostTimeCostcenter $fixedAssetLostTimeCostcenter)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(FixedAssetLostTimeCostcenter $fixedAssetLostTimeCostcenter)
    {
        //
    }
}
