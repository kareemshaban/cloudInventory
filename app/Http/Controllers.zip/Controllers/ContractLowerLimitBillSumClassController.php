<?php

namespace App\Http\Controllers;

use App\Models\ContractLowerLimitBillSumClass;
use Illuminate\Http\Request;

class ContractLowerLimitBillSumClassController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(ContractLowerLimitBillSumClass $contractLowerLimitBillSumClass)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ContractLowerLimitBillSumClass $contractLowerLimitBillSumClass)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, ContractLowerLimitBillSumClass $contractLowerLimitBillSumClass)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ContractLowerLimitBillSumClass $contractLowerLimitBillSumClass)
    {
        //
    }
}
