<?php

namespace App\Http\Controllers;

use App\Models\GoldCatchReceipt;
use Illuminate\Http\Request;

class GoldCatchReceiptController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(GoldCatchReceipt $goldCatchReceipt)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(GoldCatchReceipt $goldCatchReceipt)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, GoldCatchReceipt $goldCatchReceipt)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(GoldCatchReceipt $goldCatchReceipt)
    {
        //
    }
}
