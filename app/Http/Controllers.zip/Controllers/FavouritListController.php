<?php

namespace App\Http\Controllers;

use App\Models\FavouritList;
use Illuminate\Http\Request;

class FavouritListController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(FavouritList $favouritList)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(FavouritList $favouritList)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, FavouritList $favouritList)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(FavouritList $favouritList)
    {
        //
    }
}
