<?php

namespace App\Http\Controllers;

use App\Models\LtTable;
use Illuminate\Http\Request;

class LtTableController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(LtTable $ltTable)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(LtTable $ltTable)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, LtTable $ltTable)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(LtTable $ltTable)
    {
        //
    }
}
