<?php

namespace App\Http\Controllers;

use App\Models\LtTemp;
use Illuminate\Http\Request;

class LtTempController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(LtTemp $ltTemp)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(LtTemp $ltTemp)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, LtTemp $ltTemp)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(LtTemp $ltTemp)
    {
        //
    }
}
