<?php

namespace App\Http\Controllers;

use App\Models\TaxPolicy;
use Illuminate\Http\Request;

class TaxPolicyController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(TaxPolicy $taxPolicy)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(TaxPolicy $taxPolicy)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, TaxPolicy $taxPolicy)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(TaxPolicy $taxPolicy)
    {
        //
    }
}
