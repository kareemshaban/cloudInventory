<?php

namespace App\Http\Controllers;

use App\Models\DoctorVacation;
use Illuminate\Http\Request;

class DoctorVacationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(DoctorVacation $doctorVacation)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(DoctorVacation $doctorVacation)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, DoctorVacation $doctorVacation)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(DoctorVacation $doctorVacation)
    {
        //
    }
}
